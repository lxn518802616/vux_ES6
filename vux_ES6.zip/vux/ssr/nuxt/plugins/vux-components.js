import Vue from 'vue'
import { Group, Cell } from 'vux'

Vue.component('group', Group)
Vue.component('cell', Cell)
