<template>
  <nuxt></nuxt>
</template>

<style>
body {
  background-color: #fbf9fe;
}
</style>