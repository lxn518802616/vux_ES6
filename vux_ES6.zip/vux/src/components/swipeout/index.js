/**
* Thanks to: http://jdc.jd.com/demo/slide_to_remove/
*/

import Swipeout from './swipeout.vue'
import SwipeoutItem from './swipeout-item.vue'
import SwipeoutButton from './swipeout-button.vue'

export {
  Swipeout,
  SwipeoutItem,
  SwipeoutButton
}
