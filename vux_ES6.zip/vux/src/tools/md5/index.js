import md5 from 'blueimp-md5'
export default md5
